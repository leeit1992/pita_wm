<?php
/*
Plugin Name: PITA THEME
Plugin URI: https://pitathemes.com/
Description: Plugin require for theme.
Version: 1.0
Author: Automattic
Text Domain: pita_wm
*/

define( 'PITA_FILE', __FILE__ );
define( 'PITA_FILENAME', basename( __FILE__ ) );
define( 'PITA_PLUGIN_NAME', plugin_basename( dirname( __FILE__ ) ) );
define( 'PITA_PLUGIN_DIR', trailingslashit( __DIR__ ) );
define( 'PITA_BASE_URL_PLUGIN', untrailingslashit( plugins_url( '', PITA_FILE ) ) );
define( 'PITA_VERSION','1.0.0' );

include 'inc/pita_wm.php';
