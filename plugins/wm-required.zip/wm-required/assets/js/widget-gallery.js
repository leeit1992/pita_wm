jQuery(document).ready(function($) {
	"use strict";
	var gallery;
	var image_gallery = $('.pita_list_images');
	var galler_contaner = $('.pita_list_images');
	$('body').on('click',".pita_add_gallery", function()
	{
		
        var self = $(this);
        var attachment_id = image_gallery.val();
        //If the uploader object has already been created, reopen the dialog
        if (gallery) {
            gallery.open();
            return false;
        }
       
       
        //Extend the wp.media object
        gallery = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image', 
            button: {
                text: 'Choose Image'
            },
            multiple: true
        });
        //When a file is selected, grab the URL and set it as the text field's value
        gallery.on('select', function() {
            
            var selection = gallery.state().get('selection');
  			$('.pita_no_images').hide();
  			var pita_widget_name = self.closest('#pita_widget_images_container').find('.pita_widget_name').val();
  			console.log(pita_widget_name);
            selection.map( function( attachment ) {

				attachment = attachment.toJSON();
				if ( attachment.id ) {                    
					

                    attachment_id = attachment_id ? attachment_id + "," + attachment.id : attachment.id;
					galler_contaner.append('\
						<li class="image image-'+ attachment.id +'" data-attachment_id="' + attachment.id + '">\
							<img src="' + attachment.url + '" />\n\
                            <input type="hidden" name="' + pita_widget_name + '[]" value="' + attachment.id + '" >\n\
							<ul class="actions">\
								<li><a class="delete" data-id="'+ attachment.id +'" title="delete">delete</a></li>\
							</ul>\
						</li>');
				}

			});
            image_gallery.val( attachment_id );
        });

        gallery.open();
        return false;
	});

        
	$("body").on('click', '.delete', function(){
		var id_image = $(this).attr("data-id");
                $(".image-"+id_image).remove();
    
	});


	galler_contaner.sortable({
		items: 'li.image',
		cursor: 'move',
		scrollSensitivity:40,
		forcePlaceholderSize: true,
		forceHelperSize: false,
		helper: 'clone',
		opacity: 0.65,
		start:function(event,ui){
			ui.item.css('background-color','#f6f6f6');
		},
		stop:function(event,ui){
			ui.item.removeAttr('style');
		},
		update: function(event, ui) {
			var array_id=[];

			$('.awe_gallery_images li.image').css('cursor','default').each(function() {

				var attachment_id = $(this).data( 'attachment_id' );
                if(attachment_id!=undefined)
                    array_id.push(attachment_id);
			});
            if(array_id.length>0)
			    room_image_gallery.val( JSON.stringify(array_id));
		}
	});

});