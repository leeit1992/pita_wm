<?php
namespace PitaPlugin\Shortcode;

class Features extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_features';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);
        $listItems = vc_param_group_parse_atts( $atts['items'] );
        ob_start();

        include $this->parent->locateTemplate('features.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'Theme features', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_title_sub',
                'heading'   => esc_html__('Title sub', 'pita_wm'),
                'value'     => __( 'Hotel & Resort WordPress Theme', 'pita_wm' )
            ),
            array(
                'type'       => 'param_group',
                'param_name' => 'items',
                'heading'    => esc_html__( 'Items', 'pita_wm' ),
                'description'=> esc_html__('Chosse 4 item.', 'pita_wm'),
                'params'     => array(
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'features_heading',
                        'heading'   => esc_html__( 'Heading', 'pita_wm' ),
                        'value'     => __( 'Awebooking', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'features_content',
                        'heading'   => esc_html__( 'Content', 'pita_wm' ),
                        'value'     => __( 'Easily and quickly making as well as managing reservations, room-types, room capacity, payments and more with the top-notch, user-friendly and seamless online booking system - Awebooking.', 'pita_wm' )
                    ),
                ),
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_info_label_1',
                'heading'   => esc_html__('Info label 1', 'pita_wm'),
                'value'     => __( 'Version:', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_info_item_1',
                'heading'   => esc_html__('Info item 1', 'pita_wm'),
                'value'     => '1.0'
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_info_label_2',
                'heading'   => esc_html__('Info label 2', 'pita_wm'),
                'value'     => __( 'Updated:', 'pita_wm' )
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_info_link_2',
                'heading'   => esc_html__('Info link 2', 'pita_wm'),
                'value'     => '#'
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_info_item_2',
                'heading'   => esc_html__('Info item 2', 'pita_wm'),
                'value'     => '01 Mar 2018'
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_button_1',
                'heading'   => esc_html__('Button 1', 'pita_wm'),
                'value'     => __( 'Theme\'s Document', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_link_1',
                'heading'   => esc_html__('Link 1', 'pita_wm'),
                'value'     => '#'
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_button_2',
                'heading'   => esc_html__('Button 2', 'pita_wm'),
                'value'     => __( 'Support Forum', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_link_2',
                'heading'   => esc_html__('Link 2', 'pita_wm'),
                'value'     => '#'
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'features_button_3',
                'heading'   => esc_html__('Button 3', 'pita_wm'),
                'value'     => __( 'Download', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_link_3',
                'heading'   => esc_html__('Link 3', 'pita_wm'),
                'value'     => '#'
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_button_4',
                'heading'   => esc_html__('Button 4', 'pita_wm'),
                'value'     => __( 'Demo', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'features_link_4',
                'heading'   => esc_html__('Link 4', 'pita_wm'),
                'value'     => '#'
            ),
            
        );

        return array(
            'name'       => esc_html__('Features', 'pita_wm'),
            'description'=> esc_html__('Features', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
