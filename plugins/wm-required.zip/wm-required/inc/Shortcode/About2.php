<?php
namespace PitaPlugin\Shortcode;

class About2 extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_about_2';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();

        include $this->parent->locateTemplate('about-2.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type' => 'attach_image',
                'param_name' => 'about_background',
                'heading' => esc_html__('Background', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'about_title',
                'heading' => esc_html__('Title', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'about_desc',
                'heading' => esc_html__('Description', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'about_email',
                'heading' => esc_html__('Email', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'about_address',
                'heading' => esc_html__('Address', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'about_phone',
                'heading' => esc_html__('Phone', 'pita_wm'),
            )
        );

        return array(
            'name' => esc_html__('About 2', 'pita_wm'),
            'description' => esc_html__('About 2.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
