<?php
namespace PitaPlugin\Shortcode;

class OurOffice extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_our_office';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();

        include $this->parent->locateTemplate('our-office.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type' => 'attach_image',
                'param_name' => 'office_background',
                'heading' => esc_html__('Background', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'office_title',
                'heading' => esc_html__('Title', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'office_desc',
                'heading' => esc_html__('Description', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'office_email',
                'heading' => esc_html__('Email', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'office_address',
                'heading' => esc_html__('Address', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'office_phone',
                'heading' => esc_html__('Phone', 'pita_wm'),
            )
        );

        return array(
            'name' => esc_html__('Our Office', 'pita_wm'),
            'description' => esc_html__('Our Office.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
