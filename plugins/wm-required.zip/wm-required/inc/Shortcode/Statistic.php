<?php
namespace PitaPlugin\Shortcode;

class Statistic extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_statistic';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listItems = vc_param_group_parse_atts( $atts['items'] );

        ob_start();

        include $this->parent->locateTemplate('statistic.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'attach_image',
                'param_name'=> 'statistic_background',
                'heading'   => esc_html__('Background', 'pita_wm'),
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'statistic_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'fun facts', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'statistic_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'Fusce eros purus, tempus vitae congue non, tincidunt eget elit rhoncus nec nulla ac', 'pita_wm' )
            ),
            array(
                'type'       => 'param_group',
                'param_name' => 'items',
                'heading'    => esc_html__( 'List statistic', 'pita_wm' ),
                'description'=> esc_html__('Chosse  4 item statistic.', 'pita_wm'),
                'params'     => array(
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'statistic_number',
                        'heading'   => esc_html__( 'Number', 'pita_wm' ),
                        'value'     => __( '1000', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'statistic_name',
                        'heading'   => esc_html__( 'Name', 'pita_wm' ),
                        'value'     => __( 'Project Complete', 'pita_wm' )
                    )
                ),
            )
        );

        return array(
            'name'       => esc_html__('Statistic', 'pita_wm'),
            'description'=> esc_html__('Statistic.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
