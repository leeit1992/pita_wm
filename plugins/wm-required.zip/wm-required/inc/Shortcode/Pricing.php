<?php
namespace PitaPlugin\Shortcode;

class Pricing extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_pricing';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listItems = vc_param_group_parse_atts( $atts['items'] );

        ob_start();

        include $this->parent->locateTemplate('pricing.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'textfield',
                'param_name'=> 'pricing_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'PRICING', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'pricing_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'An eye for detail makes our works excellent', 'pita_wm' )
            ),
            array(
                'type'       => 'param_group',
                'param_name' => 'items',
                'heading'    => esc_html__( 'Items', 'pita_wm' ),
                'description'=> esc_html__('Chosse 4 item.', 'pita_wm'),
                'params'     => array(
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'pricing_name',
                        'heading'   => esc_html__( 'Name', 'pita_wm' ),
                        'value'     => __( 'Basic', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'pricing_desc_2',
                        'heading'   => esc_html__( 'Description', 'pita_wm' ),
                        'value'     => __( 'Eusto quis interdum', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'pricing_price',
                        'heading'   => esc_html__( 'Price', 'pita_wm' ),
                        'value'     => '19,9'
                    ),
                    array(
                        'type'      => 'textarea',
                        'param_name'=> 'pricing_list',
                        'heading'   => esc_html__( 'List data', 'pita_wm' ),
                        'value'     => '<ul>
                                            <li>Unlimited products</li>
                                            <li>1 GB File storage</li>
                                            <li>2.0% Transaction fee</li>
                                            <li>Discount code engine</li>
                                        </ul>'
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'pricing_link',
                        'heading'   => esc_html__('Link', 'pita_wm'),
                        'value'     => '#'
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'pricing_button',
                        'heading'   => esc_html__('Text button', 'pita_wm'),
                        'value'     => __( 'Sign up', 'pita_wm' )
                    ),
                ),
            )
            
        );

        return array(
            'name'       => esc_html__('Pricing', 'pita_wm'),
            'description'=> esc_html__('Pricing.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
