<?php
namespace PitaPlugin\Shortcode;

class Teams extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_teams';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listItems = vc_param_group_parse_atts( $atts['items'] );

        ob_start();

        include $this->parent->locateTemplate('teams.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'textfield',
                'param_name'=> 'teams_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'Creative teams', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'teams_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'Our creative minds will make your ideas possible', 'pita_wm' )
            ),
            array(
                'type'       => 'param_group',
                'param_name' => 'items',
                'heading'    => esc_html__( 'Teams', 'pita_wm' ),
                'description'=> esc_html__('Chosse 3 item.', 'pita_wm'),
                'params'     => array(
                    array(
                        'type'      => 'attach_image',
                        'param_name'=> 'teams_avatar',
                        'heading'   => esc_html__('Avatar', 'pita_wm'),
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'teams_name',
                        'heading'   => esc_html__( 'Full name', 'pita_wm' ),
                        'value'     => __( 'ANDREW CLARK', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'teams_job',
                        'heading'   => esc_html__( 'Position Jobs', 'pita_wm' ),
                        'value'     => __( 'Developer', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textarea',
                        'param_name'=> 'teams_bio',
                        'heading'   => esc_html__( 'Biography', 'pita_wm' ),
                        'value'     => __( 'Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas faucibus mollis interdum.', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'teams_twitter',
                        'heading'   => esc_html__( 'Twitter', 'pita_wm' ),
                        'value'     => '#'
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'teams_dribbble',
                        'heading'   => esc_html__( 'Dribbble', 'pita_wm' ),
                        'value'     => '#'
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'teams_tumblr',
                        'heading'   => esc_html__( 'Tumblr', 'pita_wm' ),
                        'value'     => '#'
                    ),
                ),
            )
        );

        return array(
            'name'       => esc_html__('Teams', 'pita_wm'),
            'description'=> esc_html__('Teams.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
