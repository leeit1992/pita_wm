<?php
namespace PitaPlugin\Shortcode;

class Header extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_header';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();

        include $this->parent->locateTemplate('header.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'       => 'attach_images',
                'param_name' => 'header_background',
                'heading'    => esc_html__('Slider background', 'pita_wm')
            ),
            array(
                'type'       => 'attach_image',
                'param_name' => 'header_logo',
                'heading'    => esc_html__('Logo', 'pita_wm')
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_title',
                'heading'    => esc_html__('Title', 'pita_wm'),
                'value'      => __( 'DESIGN', 'pita_wm' )
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_title_sub',
                'heading'    => esc_html__('Title sub', 'pita_wm'),
                'value'      => __( ' FOR FUTURE', 'pita_wm' )
            ),
            array(
                'type'       => 'textarea',
                'param_name' => 'header_desc',
                'heading'    => esc_html__('Description', 'pita_wm'),
                'value'      => __( 'WE creat awesome wordpress themes', 'pita_wm' )
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_button_title',
                'heading'    => esc_html__('Title button', 'pita_wm'),
                'value'      => __( 'Our work', 'pita_wm' )
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_button_link',
                'heading'    => esc_html__('Link button', 'pita_wm'),
                'value'      => '#'
            ),
            // link social
            array(
                'type'       => 'textfield',
                'param_name' => 'header_twitter',
                'heading'    => esc_html__('Twitter', 'pita_wm'),
                'value'      => '#'
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_linkedin',
                'heading'    => esc_html__('Linkedin', 'pita_wm'),
                'value'      => '#'
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_pinterest',
                'heading'    => esc_html__('Pinterest', 'pita_wm'),
                'value'      => '#'
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_google',
                'heading'    => esc_html__('Google +', 'pita_wm'),
                'value'      => '#'
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_dribbblee',
                'heading'    => esc_html__('Dribbble', 'pita_wm'),
                'value'      => '#'
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'header_vimeo',
                'heading'    => esc_html__('Vimeo', 'pita_wm'),
                'value'      => '#'
            ),
        );

        return array(
            'name'        => esc_html__('Header', 'pita_wm'),
            'description' => esc_html__('Header 1.', 'pita_wm'),
            'category'    => $this->get_category(),
            'icon'        => $this->get_icon(),
            'params'      => $params,
        );
    }
}
