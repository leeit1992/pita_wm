<?php
namespace PitaPlugin\Shortcode;

class Menus extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_menus';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();
        ?>
        <nav id="navigation" class="nav-ver1 nav-static">
        
            <div class="container">
                <div class="row">
            
                    <div class="logo"><a href="#"><img src="<?php echo isset( $atts['menu_logo'] ) ? wp_get_attachment_url( $atts['menu_logo'] ) : '' ?>" alt=""></a></div>
                    <div class="menu-mobile"><p>Menu</p></div>
        <?php
        wp_nav_menu( array(
            'theme_location' => 'primary'
        ) );
        ?>
                </div>
            </div>
        
        </nav>
        <?php
        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'        => 'attach_image',
                'param_name'  => 'menu_logo',
                'heading'     => esc_html__( 'Logo', 'pita_wm' ),
            ),
        );

        return array(
            'name' => esc_html__('Menus', 'pita_wm'),
            'description' => esc_html__('Menus.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
