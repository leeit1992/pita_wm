<?php
namespace PitaPlugin\Shortcode;

class LastedPost extends AbstractShortcode
{
    public function __construct($self = null)
    {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_lasted_post';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listPost = get_posts([
            'order' => isset($atts['order_by']) ? $atts['order_by'] : 'DESC',
            'numberposts' => isset($atts['number_post']) ? $atts['number_post'] : 3
        ]);

        ob_start();

        include $this->parent->locateTemplate('lasted-post.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map()
    {
        $params = array(
            array(
                'type' => 'textfield',
                'param_name' => 'post_title',
                'heading' => esc_html__('Title', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'post_desc',
                'heading' => esc_html__('Description', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'number_post',
                'heading' => esc_html__('Number Of Post', 'pita_wm'),
            ),
            array(
                'type' => 'dropdown',
                'param_name' => 'order_by',
                'heading' => esc_html__('Order By', 'pita_wm'),
                'value' => array(
                    __('DESC', 'pita_wm') => 'DESC',
                    __('ASC', 'pita_wm') => 'ASC',
                ),
            ),
        );

        return array(
            'name' => esc_html__('Lasted Post', 'pita_wm'),
            'description' => esc_html__('Lasted Post.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
