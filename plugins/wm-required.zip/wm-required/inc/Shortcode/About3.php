<?php
namespace PitaPlugin\Shortcode;

class About3 extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_about_3';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();

        include $this->parent->locateTemplate('about-3.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'attach_image',
                'param_name'=> 'about_background',
                'heading'   => esc_html__('Background', 'pita_wm'),
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'about_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'ROSEWOOD', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'about_title_sub',
                'heading'   => esc_html__('Title sub', 'pita_wm'),
                'value'     => __( 'Hotel & Resort WordPress Theme', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'about_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'Offering a right design and powerful features to create a successful booking website. Your hotel will be definitely ensured to encourage more and more visitors to make reservations with Rosewood.', 'pita_wm' )
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'about_button_1',
                'heading'   => esc_html__('Button 1', 'pita_wm'),
                'value'     => __( 'Demo', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'about_link_1',
                'heading'   => esc_html__('Link 1', 'pita_wm'),
                'value'     => '#'
            ),

            array(
                'type'      => 'textfield',
                'param_name'=> 'about_button_2',
                'heading'   => esc_html__('Button 2', 'pita_wm'),
                'value'     => __( 'Join to Download', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'about_link_2',
                'heading'   => esc_html__('Link 2', 'pita_wm'),
                'value'     => '#'
            ),
            array(
                'type'      => 'attach_image',
                'param_name'=> 'about_image',
                'heading'   => esc_html__('Image', 'pita_wm'),
            ),
            
        );

        return array(
            'name'       => esc_html__('About 3', 'pita_wm'),
            'description'=> esc_html__('About 3.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
