<?php
namespace PitaPlugin\Shortcode;

class Quote2 extends AbstractShortcode
{
    public function __construct($self = null)
    {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_list_quote_2';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listQuote = vc_param_group_parse_atts( $atts['list_quote_2'] );

        ob_start();

        include $this->parent->locateTemplate('quote-2.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map()
    {
        $params = array(
            array(
                'type'      => 'attach_image',
                'param_name'=> 'quote_background',
                'heading'   => esc_html__('Background', 'pita_wm'),
            ),
            array(
                'type'       => 'textfield',
                'param_name' => 'quote_icon',
                'heading'    => esc_html__('Icon', 'pita_wm'),
                'description'=> esc_html__('See list icon in -> https://icomoon.io/#preview-free', 'pita_wm'),
                'value'      => 'twitter'
            ),
            array(
                'type'      => 'param_group',
                'param_name'=> 'list_quote_2',
                'heading'   => esc_html__( 'List Quote', 'pita_wm' ),
                'params'    => array(
                    array(
                        'type'      => 'textarea',
                        'param_name'=> 'quote_content',
                        'heading'   => esc_html__( 'Content', 'pita_wm' ),
                        'value'     => __( 'Aliquam tortor leo, pharetra non congue sit amet, bibendum sit amet enim.
                            Nullam sit amet malesuada justo.', 'pita_wm' )
                    ),
                    array(
                        'type'      => 'textfield',
                        'param_name'=> 'quote_time',
                        'heading'   => esc_html__( 'Time ago', 'pita_wm' ),
                        'value'     => __( '1 month ago', 'pita_wm' )
                    )
                ),
            )
        );

        return array(
            'name'       => esc_html__('Quote 2', 'pita_wm'),
            'description'=> esc_html__('Quote 2.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
