<?php
namespace PitaPlugin\Shortcode;

class Portfolio extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_portfolio';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);
        $listPost = new \WP_Query([
            'post_type' => 'pita_portfolio',
            'posts_per_page' => isset($atts['number_post']) ? $atts['number_post'] : 3,
            // 'tax_query' => array(
            //     'relation' => 'AND',    
            //     array(
            //         'taxonomy' => 'pita_cat_service',
            //         'field' => 'id',
            //         'terms' => array( isset($atts['by_cat']) ? $atts['by_cat'] : 0 ),
            //         'include_children' => false,
            //     ) 
            // )
        ]);
        //print_r( $listPost );die;

        $listCatSystem = get_categories(['taxonomy' => 'pita_cat_portfolio']);


        /*foreach ($listPost as  $value) {
            $cat = get_the_terms( $value->ID, 'pita_cat_portfolio');
            print_r($cat);
            $textSlug = '';
            foreach ($cat as $value) {
                $textSlug .= $value->slug .' ';
            }
            echo trim( $textSlug );
            die;
        }*/
        ob_start();

        include $this->parent->locateTemplate('portfolio.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type' => 'textfield',
                'param_name' => 'portfolio_title',
                'heading' => esc_html__('Title', 'pita_wm'),
            ),
            array(
                'type' => 'textarea',
                'param_name' => 'portfolio_desc',
                'heading' => esc_html__('Description', 'pita_wm'),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'number_post',
                'heading' => esc_html__('Number Of Post', 'pita_wm'),
            ),
            array(
                'type' => 'dropdown',
                'param_name' => 'order_by',
                'heading' => esc_html__('Order By', 'pita_wm'),
                'value' => array(
                    __('DESC', 'pita_wm') => 'DESC',
                    __('ASC', 'pita_wm') => 'ASC',
                ),
            ),
            
        );

        return array(
            'name' => esc_html__('Portfolio', 'pita_wm'),
            'description' => esc_html__('Portfolio.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
