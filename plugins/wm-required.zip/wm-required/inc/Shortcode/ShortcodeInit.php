<?php
namespace PitaPlugin\Shortcode;

use PitaPlugin\Shortcode\Header;
use PitaPlugin\Shortcode\Menus;
use PitaPlugin\Shortcode\Skills;
use PitaPlugin\Shortcode\Teams;
use PitaPlugin\Shortcode\Statistic;
use PitaPlugin\Shortcode\Pricing;
use PitaPlugin\Shortcode\Quote1;
use PitaPlugin\Shortcode\Quote2;
use PitaPlugin\Shortcode\Subscribe;
use PitaPlugin\Shortcode\ListClient;
use PitaPlugin\Shortcode\LastedPost;
use PitaPlugin\Shortcode\Portfolio;
use PitaPlugin\Shortcode\Service;
use PitaPlugin\Shortcode\About1;
use PitaPlugin\Shortcode\About2;
use PitaPlugin\Shortcode\Contact1;
use PitaPlugin\Shortcode\Contact2;

/**
 * Shortcode init
 */
class ShortcodeInit 
{
	
	function __construct() {
		add_action( 'plugins_loaded', array($this, 'includeTemplate') );
	}

	public function includeTemplate() {

		new Header($this);
		new Menus($this);
		new Skills($this);
		new Teams($this);
		new Statistic($this);
		new Pricing($this);
		new Quote1($this);
		new Quote2($this);
		new Subscribe($this);
		new ListClient($this);
		new LastedPost($this);
		new Portfolio($this);
		new Service($this);
		new About1($this);
		new About2($this);
		new Contact1($this);
		new Contact2($this);
	}

	/**
	 * Get template path.
	 *
	 * @param  string $filename Filename with extension.
	 * @return string           Template path.
	 */
	public function locateTemplate( $filename ) {

		$theme_dir = apply_filters( 'pita_wm_shortcode_template_theme_dir', 'shortcodes/' );
		$plugin_path = PITA_PLUGIN_DIR . 'templates/shortcodes/';

		$path = '';

		if ( locate_template( $theme_dir . $filename ) ) {
			$path = locate_template( $theme_dir . $filename );
		} elseif ( file_exists( $plugin_path . $filename ) ) {
			$path = $plugin_path . $filename;
		}
		
		return apply_filters( 'pita_wm_shortcode_template_theme_dir', $path, $filename );

	}
}
