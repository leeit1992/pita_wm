<?php
namespace PitaPlugin\Shortcode;

use PitaPlugin\Shortcode\LastedPost;
use PitaPlugin\Shortcode\OurOffice;
use PitaPlugin\Shortcode\Contact;

/**
 * Shortcode init
 */
class ShortcodeInit 
{
	
	function __construct() {
		add_action( 'plugins_loaded', array($this, 'includeTemplate') );
	}

	public function includeTemplate() {
		new LastedPost($this);
		new OurOffice($this);
		new Contact($this);
	}

	/**
	 * Get template path.
	 *
	 * @param  string $filename Filename with extension.
	 * @return string           Template path.
	 */
	public function locateTemplate( $filename ) {

		$theme_dir = apply_filters( 'pita_wm_shortcode_template_theme_dir', 'shortcodes/' );
		$plugin_path = PITA_PLUGIN_DIR . 'templates/shortcodes/';

		$path = '';

		if ( locate_template( $theme_dir . $filename ) ) {
			$path = locate_template( $theme_dir . $filename );
		} elseif ( file_exists( $plugin_path . $filename ) ) {
			$path = $plugin_path . $filename;
		}
		
		return apply_filters( 'pita_wm_shortcode_template_theme_dir', $path, $filename );

	}
}
