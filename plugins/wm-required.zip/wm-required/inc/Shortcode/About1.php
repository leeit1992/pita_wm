<?php
namespace PitaPlugin\Shortcode;

class About1 extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_about_1';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listItems = vc_param_group_parse_atts( $atts['items'] );

        ob_start();

        include $this->parent->locateTemplate('about-1.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'textfield',
                'param_name'=> 'about_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'ABOUT w&amp;M', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'about_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'We’re branding &amp; digital studio from New York', 'pita_wm' )
            ),
            array(
                'type'       => 'param_group',
                'param_name' => 'items',
                'heading'    => esc_html__( 'List info', 'pita_wm' ),
                'description'=> esc_html__('Chosse 3 info.', 'pita_wm'),
                'params'     => array(
                    array(
                        'type'        => 'textfield',
                        'param_name'  => 'about_icon',
                        'heading'     => esc_html__( 'Icon', 'pita_wm' ),
                        'description' => esc_html__('See list icon in -> http://fontawesome.io/icons', 'pita_wm'),
                        'value'       => 'lightbulb-o'
                    ),
                    array(
                        'type'        => 'textfield',
                        'param_name'  => 'about_link',
                        'heading'     => esc_html__( 'Link', 'pita_wm' ),
                        'value'       => '#'
                    ),
                    array(
                        'type'        => 'textfield',
                        'param_name'  => 'about_title_2',
                        'heading'     => esc_html__( 'Title', 'pita_wm' ),
                        'value'       => __( 'Great Features', 'pita_wm' )
                    ),
                    array(
                        'type'        => 'textarea',
                        'param_name'  => 'about_desc_2',
                        'heading'     => esc_html__( 'Description', 'pita_wm' ),
                        'value'       => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly', 'pita_wm' )
                    )
                ),
            )
        );

        return array(
            'name'       => esc_html__('About 1', 'pita_wm'),
            'description'=> esc_html__('About 1.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
