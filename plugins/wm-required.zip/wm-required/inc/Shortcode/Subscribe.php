<?php
namespace PitaPlugin\Shortcode;

class Subscribe extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_subscribe';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        ob_start();

        include $this->parent->locateTemplate('subscribe.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'        => 'textfield',
                'param_name'  => 'subscribe_icon',
                'heading'     => esc_html__( 'Icon', 'pita_wm' ),
                'description' => esc_html__('See list icon in -> https://icomoon.io/#preview-free', 'pita_wm'),
            ),

            array(
                'type' => 'textfield',
                'param_name' => 'subscribe_title',
                'heading' => esc_html__('Title', 'pita_wm'),
            ),

            array(
                'type' => 'textarea',
                'param_name' => 'subscribe_desc',
                'heading' => esc_html__('Description', 'pita_wm'),
            ),

            array(
                'type' => 'textfield',
                'param_name' => 'subscribe_button',
                'heading' => esc_html__('Title button', 'pita_wm'),
            ),
        );

        return array(
            'name' => esc_html__('Subscribe', 'pita_wm'),
            'description' => esc_html__('Subscribe.', 'pita_wm'),
            'category' => $this->get_category(),
            'icon' => $this->get_icon(),
            'params' => $params,
        );
    }
}
