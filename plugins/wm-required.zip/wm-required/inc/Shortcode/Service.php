<?php
namespace PitaPlugin\Shortcode;

class Service extends AbstractShortcode
{
    public function __construct($self = null) {
        $this->parent = $self;
        add_shortcode($this->get_name(), array($this, 'render'));
        vc_lean_map($this->get_name(), array($this, 'map'));
    }

    /**
     * Get shortcode name.
     *
     * @return string
     */
    public function get_name() {
        return 'pita_service';
    }

    /**
     * Shortcode handler.
     *
     * @param array $atts Shortcode attributes.
     *
     * @return string Shortcode output.
     */
    public function render($atts) {
        $atts = vc_map_get_attributes($this->get_name(), $atts);

        $atts = array_map('trim', $atts);

        $listPost =  get_posts([
            'post_type'  => 'pita_service',
            'order'      => isset($atts['order_by']) ? $atts['order_by'] : 'DESC',
            'numberposts'=> isset($atts['number_post']) ? $atts['number_post'] : 3
        ]);
        ob_start();

        include $this->parent->locateTemplate('service.tpl.php');

        return ob_get_clean();
    }

    /**
     * Get shortcode settings.
     *
     * @return array
     *
     * @see vc_lean_map()
     */
    public function map() {
        $params = array(
            array(
                'type'      => 'textfield',
                'param_name'=> 'service_title',
                'heading'   => esc_html__('Title', 'pita_wm'),
                'value'     => __( 'Services', 'pita_wm' )
            ),
            array(
                'type'      => 'textarea',
                'param_name'=> 'service_desc',
                'heading'   => esc_html__('Description', 'pita_wm'),
                'value'     => __( 'We provide best digital solutions for your project', 'pita_wm' )
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'number_post',
                'heading'   => esc_html__('Number Of Post', 'pita_wm'),
                'value'     => 3
            ),
            array(
                'type'      => 'dropdown',
                'param_name'=> 'order_by',
                'heading'   => esc_html__('Order By', 'pita_wm'),
                'value'     => array(
                    __('DESC', 'pita_wm')=> 'DESC',
                    __('ASC', 'pita_wm') => 'ASC',
                ),
            ),
            array(
                'type'      => 'textfield',
                'param_name'=> 'service_link',
                'heading'   => esc_html__('Link', 'pita_wm'),
                'value'     => '#'
            ),
            
        );

        return array(
            'name'       => esc_html__('Service', 'pita_wm'),
            'description'=> esc_html__('Service.', 'pita_wm'),
            'category'   => $this->get_category(),
            'icon'       => $this->get_icon(),
            'params'     => $params,
        );
    }
}
