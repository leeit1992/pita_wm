<?php
namespace PitaPlugin;

/**
 * @category Core
 * @version 1.0
 * @author Pita
 */

if (!class_exists('PitaWM')) :

class PitaWM
{
    private static $getInstance = null;

    public $version = '1.0';

    /**
     * Get the instane of builder core.
     *
     * @return object
     */
    public static function getInstance()
    {
        if (!(self::$getInstance instanceof self)) {
            self::$getInstance = new self();
        }

        return self::$getInstance;
    }

    public function __construct()
    {
        $this->defineConstants();

        $this->loadModule();

        $this->init();
        $this->initHook();
    }

    /**
	 * Include required core files used in admin and on the frontend.
	 */
    public function init()
    {	
        if( class_exists('ReduxFrameworkPlugin') ) {
            new Admin\ThemeSettings;
        }
       
    	new Admin\RegisterPostType;
        if( class_exists('WPBakeryShortCode') ){
            $this->shortcode = new Shortcode\ShortcodeInit;
        }
        
    	$this->widget = new Widget\InitWidget;
    }

    /**
	 * Hook into actions and filters.
	 * @since  1.0
	 */
    public function initHook()
    {

    }

    /**
	 * Define PitaTaxinv Constants.
	 */
    public function defineConstants()
    {

    }

    /**
	 * Define constant if not already set.
	 *
	 * @param  string $name
	 * @param  string|bool $value
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
     * load_module.
     * Load module for PitaPlugig.
     */
    protected function loadModule()
    {
        require_once 'Autoload/Autoload.php';

        do_action('pita_wm_load_module');

        Autoload::getInstance();
    }

}

/**
 * Return Instance plugin.
 */
function PitaWM()
{   
    return PitaWM::getInstance();
}

$GLOBALS['pita_wm'] = PitaWM();

// Get setting plugin.
// $GLOBALS['apbSettings'] = get_option('_awebookingSettings');
endif;
