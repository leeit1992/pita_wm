<?php
class Flickr extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'WM Flickr' );
	}
	function widget( $args, $instance ) {
		?>
		<aside class="flickr">
            <h2 class="title-right-blog"><?php echo $instance['title'] ?></h2>
            <ul class="content-flickr">
            	<?php foreach ($instance['images'] as $value): ?>
            		<li>
	                    <a href="#" title="">
	                        <img src="<?php echo wp_get_attachment_url( $value ); ?>" alt=""/>
	                    </a>
	                </li>
            	<?php endforeach ?>
                
            </ul>
        </aside>
		<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['images'] = ( ! empty( $new_instance['images'] ) ) ? $new_instance['images'] : [];
		return $instance;
	}

	function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'pita_wm' );
		$images = ! empty( $instance['images'] ) ? (array) $instance['images'] : [];
		?>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'pita_wm' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<label>Images:</label> 
		<div id="pita_widget_images_container">
			<?php if ( empty( $images ) ): ?>
			<div class="pita_no_images">
				<p>No images selected</p>
			</div>
			<?php endif ?>
			<ul class="pita_list_images">
				<?php
				if ( isset($images) && is_array($images) ) {
					?>
						<input type="hidden" class="pita_widget_name" value="<?php echo $this->get_field_name('images'); ?>">
					<?php
					foreach ($images as $item_gallery) {
						$image = wp_get_attachment_image_src($item_gallery, 'thumbnail', false);
						?>
						<li data-attachment_id="<?php echo $item_gallery; ?>" class="image image-<?php echo $item_gallery; ?> ui-sortable-handle">
		                    <img src="<?php echo esc_attr( $image[0] )  ?>">
		                    <input type="hidden" value="<?php echo $item_gallery; ?>" name="<?php echo $this->get_field_name( 'images' ) ?>[]">
		                    <ul class="actions">								
		                        <li><a title="delete" data-id="<?php echo $item_gallery; ?>" class="delete">delete</a></li>					
		                    </ul>						
		                </li>
						<?php
					}
				}
				?>
			</ul>
			<p>
				<button type="button" class="button pita_add_gallery">
					Add Images
				</button>
			</p>
		</div>
		
		<?php
	}
}
