<?php
class NewPost extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'WM News Post' );
	}
	function widget( $args, $instance ) {
		$listPost = get_posts([
            'numberposts' => $instance['number_post']
        ]);
		?>
		<aside class="recent-post">
		    <h2 class="title-right-blog"><?php echo $instance['title'] ?></h2>
		    <ul class="ul-category">
		    <?php foreach ($listPost as $value) :?>
				<li>
                    <a href="<?php echo $value->guid; ?>" title="Blog Post With Gallery"><?php echo $value->post_title ?></a>
                </li>
			<?php endforeach; ?>
			</ul>
		</aside>
		<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['number_post'] = ( ! empty( $new_instance['number_post'] ) ) ? strip_tags( $new_instance['number_post'] ) : '';

		return $instance;
	}

	function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'pita_wm' );
		$numberPost = ! empty( $instance['number_post'] ) ? $instance['number_post'] : esc_html__( '5', 'pita_wm' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'pita_wm' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'number_post' ) ); ?>"><?php esc_attr_e( 'Number Post:', 'pita_wm' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number_post' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number_post' ) ); ?>" type="text" value="<?php echo esc_attr( $numberPost ); ?>">
		</p>
		<?php
	}
}
