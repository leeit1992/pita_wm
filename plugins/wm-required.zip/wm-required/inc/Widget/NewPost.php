<?php 

class NewPost extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'News Post' );
	}
}
