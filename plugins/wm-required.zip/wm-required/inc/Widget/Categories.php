<?php
class Categories extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'WM Categories' );
	}
	function widget( $args, $instance ) {
		$cate = get_categories( array ( 'taxonomy' => 'category') );
		?>
		<aside class="category">
            <h2 class="title-right-blog"><?php echo $instance['title'] ?></h2>
            <ul class="ul-category">
            	<?php foreach ($cate as $value): ?>
        		<li>
                    <a href="<?php echo get_home_url(). '/category/'.$value->slug; ?>" title="<?php echo $value->name; ?>"><?php echo $value->name; ?></a>
                </li>
            	<?php endforeach ?>
            </ul>
        </aside>
		<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $instance;
	}

	function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Categories', 'pita_wm' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'pita_wm' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
	}
}
