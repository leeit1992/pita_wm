<?php
namespace PitaPlugin\Widget;

/**
 * widget init
 */
class InitWidget 
{
	function __construct()
	{	
		add_action( 'admin_enqueue_scripts', array( $this, 'loadScripts' ) , 333333);
		add_action( 'admin_enqueue_scripts', array( $this, 'loadStyles' ) , 333);

		require_once 'Search.php';
		require_once 'Categories.php';
		require_once 'Flickr.php';
		require_once 'NewPost.php';
		require_once 'TextWidget.php';
		require_once 'TagsCloud.php';
		add_action( 'widgets_init', array($this, 'includeTemplate') );

	}

	public function includeTemplate(){
		register_widget( 'Search' );
		register_widget( 'Categories' );
		register_widget( 'Flickr' );
		register_widget( 'NewPost' );
		register_widget( 'TextWidget' );
		register_widget( 'TagsCloud' );
	}

	public function loadScripts(){
		wp_enqueue_script('pita-gallery', PITA_BASE_URL_PLUGIN.'/assets/js/widget-gallery.js', "", '1.0', true);
	}

	public function loadStyles(){
		wp_enqueue_style('pita-flickr-style',PITA_BASE_URL_PLUGIN. '/assets/css/widget-gallery.css');
	}
}
