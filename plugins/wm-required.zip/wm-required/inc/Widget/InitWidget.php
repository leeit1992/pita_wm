<?php
namespace PitaPlugin\Widget;

/**
 * widget init
 */
class InitWidget 
{
	function __construct()
	{	
		require_once 'Search.php';
		require_once 'NewPost.php';
		require_once 'Categories.php';
		require_once 'TextWidget.php';
		require_once 'TagsCloud.php';
		add_action( 'widgets_init', array($this, 'includeTemplate') );

	}

	public function includeTemplate(){
		register_widget( 'Search' );
		register_widget( 'NewPost' );
		register_widget( 'Categories' );
		register_widget( 'TextWidget' );
		register_widget( 'TagsCloud' );
	}
}
