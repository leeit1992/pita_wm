<?php
namespace PitaPlugin\Widget;

/**
 * widget init
 */
class InitWidget 
{
	function __construct()
	{	
		require_once 'NewPost.php';
		add_action( 'widgets_init', array($this, 'includeTemplate') );

	}

	public function includeTemplate(){
		register_widget( 'NewPost' );
	}
}
