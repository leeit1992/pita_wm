<?php
class Search extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'WM Search' );
	}
	function widget( $args, $instance ) {
	?>
		<aside class="blog-search">
            <form role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ) ?>">
                <input type="text" name="s" id="s" onfocus="if(this.value == 'To seach type and hit enter') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'To seach type and hit enter'; }" value="To seach type and hit enter"/>
            </form>
        </aside>
	<?php
	}

	function update( $new_instance, $old_instance ) {
	}

	function form( $instance ) {
	}
}
