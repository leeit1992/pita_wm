<?php
class TagsCloud extends WP_Widget {

	function __construct() {
		// Instantiate the parent object
		parent::__construct( false, 'WM Tags Cloud' );
	}
	function widget( $args, $instance ) {
		switch ( $instance['taxonomy'] ) {
			case 'category':
				$listCloud = get_categories();
				break;
			case 'tags':
				$listCloud = get_tags();
				break;
		}
		?>
		<aside class="tag-blog">
            <h2 class="title-right-blog"><?php echo $instance['title'] ?></h2>
            <ul>
            	<?php foreach ($listCloud as $value): ?>
        		<li>
                    <a href="" title="<?php echo $value->name; ?>"><?php echo $value->name; ?></a>
                </li>
            	<?php endforeach ?>
            </ul>
        </aside>
		<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['taxonomy'] = ( ! empty( $new_instance['taxonomy'] ) ) ? strip_tags( $new_instance['taxonomy'] ) : '';

		return $instance;
	}

	function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'pita_wm' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'pita_wm' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>"><?php esc_attr_e( 'Taxonomy:', 'pita_wm' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'taxonomy' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>" class="widefat">
				<option value="category"<?php selected( $instance['taxonomy'], 'category' ); ?>><?php esc_attr_e('Category', 'pita_wm' ); ?></option>
				<option value="tags"<?php selected( $instance['taxonomy'], 'tags' ); ?>><?php esc_attr_e('Tags', 'pita_wm' ); ?></option>
			</select>
		</p>
		<?php

	}
}
