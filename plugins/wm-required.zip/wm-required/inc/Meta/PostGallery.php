<?php
/**
 * Gallery of posts
 *
 * @author Letrungha
 */
class PostGallery
{

	public static function output( $post ){
		$gallerys = get_post_meta($post->ID,"pita_gallery",true);
		?>
		<div id="pita_images_container">
			<ul class="pita_images">
                <?php 
                    if(isset($gallerys) && is_array($gallerys)): 
                        foreach ($gallerys as $item_gallery):
                        $image = wp_get_attachment_image_src($item_gallery, 'thumbnail', false);
                ?>
                    <li data-attachment_id="<?php echo $item_gallery ?>" class="image image-<?php echo $item_gallery ?>">							
                        <img src="<?php echo esc_attr($image[0]); ?>" title="image flickr">
                        <input type="hidden" value="<?php echo $item_gallery ?>" name="pita_gallery[]">
                        <ul class="actions">								
                            <li><a title="delete" data-id="<?php echo $item_gallery ?>" class="delete">delete</a></li>					
                        </ul>						
                    </li>
               <?php endforeach; endif; ?>
            </ul>
		</div>
        <p class="add_product_images hide-if-no-js">
            <a data-choose="Add Images to Product Gallery" class="pita_add_gallery" href="#" title=" add gallery images">Add gallery images</a>
        </p>
		<?php
	}

	public static function save( $post_id ){
		if(isset($_POST['pita_gallery']) && !empty($_POST['pita_gallery'])){
            update_post_meta($post_id, "pita_gallery",wp_kses($_POST['pita_gallery'], ''));
        }else{
            update_post_meta($post_id, "pita_gallery",array());
        }
	}

}