<?php 
namespace PitaPlugin\Meta;

class MetaBoxInit
{
	
	public function __construct()
	{
		add_action( 'admin_enqueue_scripts', array( $this, 'loadScripts' ) , 1000000000);
		add_action( 'admin_enqueue_scripts', array( $this, 'loadStyles' ) , 1000000000);

		require_once 'PostGallery.php';
		
		// Add metabox
		add_action( 'add_meta_boxes', array( $this, 'postTypeGallery' ), 10 );

		// Save metabox action
		add_action( 'save_post','PostGallery::save');

	}

	public function postTypeGallery(){
		add_meta_box('pita-gallery', __('Create Gallery',"pita_wm"), 'PostGallery::output','post','side','default','');
	}

	public function loadScripts(){
		wp_enqueue_script('pita-gallery', PITA_BASE_URL_PLUGIN.'/assets/js/gallery.js', "", '1.0', true);
	}

	public function loadStyles(){
		wp_enqueue_style('awe-fullcalendar-style',PITA_BASE_URL_PLUGIN.'/assets/css/gallery.css');
	}

}