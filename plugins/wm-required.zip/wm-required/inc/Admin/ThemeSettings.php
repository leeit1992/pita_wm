<?php 
namespace PitaPlugin\Admin;
/**
 * @category Core
 * @version 1.0
 * @author Pita
 * @package Add theme settings
 */
class ThemeSettings
{
	public function __construct()
	{
		$opt_name = "pita_wm_option";
		// $theme = wp_get_theme(); 

		$args = array(
	        // TYPICAL -> Change these values as you need/desire
	        'opt_name'             => $opt_name,
	        // This is where your data is stored in the database and also becomes your global variable name.
	        // 'display_name'         => $theme->get( 'Name' ),
	        // Name that appears at the top of your panel
	        // 'display_version'      => $theme->get( 'Version' ),
	        // Version that appears at the top of your panel
	        'menu_type'            => 'menu',
	        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
	        'allow_sub_menu'       => true,
	        // Show the sections below the admin menu item or not
	        'menu_title'           => __( 'Theme Settings', 'pita_wm' ),
	        'page_title'           => __( 'Theme Setting', 'pita_wm' ),
	        // You will need to generate a Google API key to use this feature.
	        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
	        'google_api_key'       => '',
	        // Set it you want google fonts to update weekly. A google_api_key value is required.
	        'google_update_weekly' => false,
	        // Must be defined to add google fonts to the typography module
	        'async_typography'     => true,
	        // Use a asynchronous font on the front end or font string
	        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
	        'admin_bar'            => true,
	        // Show the panel pages on the admin bar
	        'admin_bar_icon'       => 'dashicons-portfolio',
	        // Choose an icon for the admin bar menu
	        'admin_bar_priority'   => 50,
	        // Choose an priority for the admin bar menu
	        'global_variable'      => '',
	        // Set a different name for your global variable other than the opt_name
	        'dev_mode'             => true,
	        // Show the time the page took to load, etc
	        'update_notice'        => true,
	        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
	        'customizer'           => true,
	        // Enable basic customizer support
	        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
	        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

	        // OPTIONAL -> Give you extra features
	        'page_priority'        => null,
	        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
	        'page_parent'          => 'themes.php',
	        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	        'page_permissions'     => 'manage_options',
	        // Permissions needed to access the options panel.
	        'menu_icon'            => '',
	        // Specify a custom URL to an icon
	        'last_tab'             => '',
	        // Force your panel to always open to a specific tab (by id)
	        'page_icon'            => 'icon-themes',
	        // Icon displayed in the admin panel next to your menu_title
	        'page_slug'            => 'pita_wm_options',
	        // Page slug used to denote the panel
	        'save_defaults'        => true,
	        // On load save the defaults to DB before user clicks save or not
	        'default_show'         => false,
	        // If true, shows the default value next to each field that is not the default value.
	        'default_mark'         => '',
	        // What to print by the field's title if the value shown is default. Suggested: *
	        // 'show_import_export'   => true,
	        // Shows the Import/Export panel when not used as a field.

	        // CAREFUL -> These options are for advanced use only
	        'transient_time'       => 60 * MINUTE_IN_SECONDS,
	        'output'               => true,
	        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
	        'output_tag'           => true,
	        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
	        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

	        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
	        'database'             => '',
	        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

	        'use_cdn'              => true,

	    );

		\Redux::setArgs( $opt_name, $args );

		\Redux::setSection( $opt_name, array(
	        'title'            => __( 'Theme Settings', 'pita_wm' ),
	        'id'               => 'basic',
	        'desc'             => __( 'These are really setting theme!', 'pita_wm' ),
	        'customizer_width' => '400px',
	        'icon'             => 'el el-home'
	    ) );

	    \Redux::setSection( $opt_name, array(
	        'title'            => __( 'Genneral Settings', 'pita_wm' ),
	        'id'               => 'theme-genneral',
	        'subsection'       => true,
	        'desc'             => __( 'Setting genneral for theme. ', 'pita_wm' ) ,
	        'fields'           => array(
	        	array(
	                'id'       => 'pita_wm-logo',
	                'type'     => 'media',
	                'title'    => __( 'Logo Menu', 'pita_wm' ),
	                'subtitle' => __( 'Logo for menu', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-preloader',
	                'type'     => 'media',
	                'title'    => __( 'Picture preloader', 'pita_wm' ),
	                'subtitle' => __( 'Picture for preloader', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-video-fixed',
	                'type'     => 'text',
	                'title'    => __( 'Video Fixed', 'pita_wm' ),
	                'subtitle' => __( 'Link youtube for video fixed', 'pita_wm' ),
	                'default'  => 'http://www.youtube.com/watch?v=RdIh8GiVR9I'
	            ),
				array(
	                'id'       => 'pita_wm-info-footer',
	                'type'     => 'ace_editor',
	                'title'    => __( 'Info footer', 'pita_wm' ),
	                'default'  => 'Created with <span class="icofont moon-heart-2"></span> by Zankover. All Rights Reserved'
	            ),
	        )
	    ) );

	    \Redux::setSection( $opt_name, array(
	        'title'            => __( 'Settings Social', 'pita_wm' ),
	        'id'               => 'pita-social',
	        'desc'             => __( 'Setting social for theme.', 'pita_wm' ),
	        'subsection'       => true,
	        'fields'           => array(
	        	array(
	                'id'       => 'pita_wm-social-icon-1',
	                'type'     => 'text',
	                'title'    => __( 'Icon social 1', 'pita_wm' ),
	                'subtitle' => __( 'See list icon in -> https://icomoon.io/#preview-free', 'pita_wm' ),
	                'default'  => 'twitter'
	            ),
	            array(
	                'id'       => 'pita_wm-social-link-1',
	                'type'     => 'text',
	                'title'    => __( 'Link social 1', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-social-icon-2',
	                'type'     => 'text',
	                'title'    => __( 'Icon social 2', 'pita_wm' ),
	                'subtitle' => __( 'See list icon in -> https://icomoon.io/#preview-free', 'pita_wm' ),
	                'default'  => 'github'
	            ),

	            array(
	                'id'       => 'pita_wm-social-link-2',
	                'type'     => 'text',
	                'title'    => __( 'Link social 2', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-social-icon-3',
	                'type'     => 'text',
	                'title'    => __( 'Icon social 3', 'pita_wm' ),
	                'subtitle' => __( 'See list icon in -> https://icomoon.io/#preview-free', 'pita_wm' ),
	                'default'  => 'dribbble'
	            ),

	            array(
	                'id'       => 'pita_wm-social-link-3',
	                'type'     => 'text',
	                'title'    => __( 'Link social 3', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-social-icon-4',
	                'type'     => 'text',
	                'title'    => __( 'Icon social 4', 'pita_wm' ),
	                'subtitle'     => __( 'See list icon in -> https://icomoon.io/#preview-free', 'pita_wm' ),
	                'default'  => 'camera-4'
	            ),
	            array(
	                'id'       => 'pita_wm-social-link-4',
	                'type'     => 'text',
	                'title'    => __( 'Link social 4', 'pita_wm' ),
	            )
	        )
	    ) );

	    \Redux::setSection( $opt_name, array(
	        'title'            => __( 'Settings Detail Post', 'pita_wm' ),
	        'id'               => 'pita-detail-post',
	        'desc'             => __( 'Setting shortcode for detail post.', 'pita_wm' ),
	        'subsection'       => true,
	        'fields'           => array(
	        	array(
	                'id'       => 'pita_wm-post-detail-head',
	                'type'     => 'ace_editor',
	                'title'    => __( 'Shortcode Header', 'pita_wm' ),
	                'subtitle'     => __( 'List Shortcode Footer', 'pita_wm' ),
	            ),
	            array(
	                'id'       => 'pita_wm-post-detail-footer',
	                'type'     => 'ace_editor',
	                'title'    => __( 'Shortcode Footer', 'pita_wm' ),
	                'subtitle'     => __( 'List Shortcode Footer', 'pita_wm' ),
	            )
	        )
	    ) );
	}
}
