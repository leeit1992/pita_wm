<?php 
namespace PitaPlugin\Admin;
/**
 * @category Core
 * @version 1.0
 * @author Pita
 * @package Add theme settings
 */
class ThemeSettings
{	
}
