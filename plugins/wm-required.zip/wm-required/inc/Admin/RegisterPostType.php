<?php 
namespace PitaPlugin\Admin;

/**
 * @category Core
 * @version 1.0
 * @author Pita
 * @package Register post type
 */
class RegisterPostType 
{
	function __construct()
	{
		add_action( 'init', array($this, 'custom_post_type'), 0 );
		add_action( 'init', array($this, 'create_taxonomies'), 0 );
	}
	// Register Custom Post Type
	public function custom_post_type() {

		/*===============================
		=            Service            =
		===============================*/
		
		$labels = array(
			'name'                 => _x( 'Services', 'Post Type General Name', 'pita_wm' ),
			'singular_name'        => _x( 'pita_service', 'Post Type Singular Name', 'pita_wm' ),
			'menu_name'            => __( 'Services', 'pita_wm' ),
			'name_admin_bar'       => __( 'Services', 'pita_wm' ),
			'archives'             => __( 'Item Archives', 'pita_wm' ),
			'attributes'           => __( 'Item Attributes', 'pita_wm' ),
			'parent_item_colon'    => __( 'Parent Item:', 'pita_wm' ),
			'all_items'            => __( 'All Items', 'pita_wm' ),
			'add_new_item'         => __( 'Add New Item', 'pita_wm' ),
			'add_new'              => __( 'Add New', 'pita_wm' ),
			'new_item'             => __( 'New Item', 'pita_wm' ),
			'edit_item'            => __( 'Edit Item', 'pita_wm' ),
			'update_item'          => __( 'Update Item', 'pita_wm' ),
			'view_item'            => __( 'View Item', 'pita_wm' ),
			'view_items'           => __( 'View Items', 'pita_wm' ),
			'search_items'         => __( 'Search Item', 'pita_wm' ),
			'not_found'            => __( 'Not found', 'pita_wm' ),
			'not_found_in_trash'   => __( 'Not found in Trash', 'pita_wm' ),
			'featured_image'       => __( 'Featured Image', 'pita_wm' ),
			'set_featured_image'   => __( 'Set featured image', 'pita_wm' ),
			'remove_featured_image'=> __( 'Remove featured image', 'pita_wm' ),
			'use_featured_image'   => __( 'Use as featured image', 'pita_wm' ),
			'insert_into_item'     => __( 'Insert into item', 'pita_wm' ),
			'uploaded_to_this_item'=> __( 'Uploaded to this item', 'pita_wm' ),
			'items_list'           => __( 'Items list', 'pita_wm' ),
			'items_list_navigation'=> __( 'Items list navigation', 'pita_wm' ),
			'filter_items_list'    => __( 'Filter items list', 'pita_wm' ),
		);
		$args = array(
			'label'              => __( 'pita_service', 'pita_wm' ),
			'description'        => __( 'Service for theme Pita W&M', 'pita_wm' ),
			'labels'             => $labels,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
			'taxonomies'         => array( 'pita_cat_service' ),
			'hierarchical'       => false,
			'public'             => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'menu_position'      => 5,
			'show_in_admin_bar'  => true,
			'show_in_nav_menus'  => true,
			'can_export'         => true,
			'has_archive'        => true,
			'exclude_from_search'=> false,
			'publicly_queryable' => true,
			'capability_type'    => 'page',
		);
		register_post_type( 'pita_service', $args );
		
		/*=====  End of Service  ======*/

		$labels = array(
			'name'                 => _x( 'Portfolio', 'Post Type General Name', 'pita_wm' ),
			'singular_name'        => _x( 'pita_portfolio', 'Post Type Singular Name', 'pita_wm' ),
			'menu_name'            => __( 'Portfolio', 'pita_wm' ),
			'name_admin_bar'       => __( 'Portfolio', 'pita_wm' ),
			'archives'             => __( 'Item Archives', 'pita_wm' ),
			'attributes'           => __( 'Item Attributes', 'pita_wm' ),
			'parent_item_colon'    => __( 'Parent Item:', 'pita_wm' ),
			'all_items'            => __( 'All Items', 'pita_wm' ),
			'add_new_item'         => __( 'Add New Item', 'pita_wm' ),
			'add_new'              => __( 'Add New', 'pita_wm' ),
			'new_item'             => __( 'New Item', 'pita_wm' ),
			'edit_item'            => __( 'Edit Item', 'pita_wm' ),
			'update_item'          => __( 'Update Item', 'pita_wm' ),
			'view_item'            => __( 'View Item', 'pita_wm' ),
			'view_items'           => __( 'View Items', 'pita_wm' ),
			'search_items'         => __( 'Search Item', 'pita_wm' ),
			'not_found'            => __( 'Not found', 'pita_wm' ),
			'not_found_in_trash'   => __( 'Not found in Trash', 'pita_wm' ),
			'featured_image'       => __( 'Featured Image', 'pita_wm' ),
			'set_featured_image'   => __( 'Set featured image', 'pita_wm' ),
			'remove_featured_image'=> __( 'Remove featured image', 'pita_wm' ),
			'use_featured_image'   => __( 'Use as featured image', 'pita_wm' ),
			'insert_into_item'     => __( 'Insert into item', 'pita_wm' ),
			'uploaded_to_this_item'=> __( 'Uploaded to this item', 'pita_wm' ),
			'items_list'           => __( 'Items list', 'pita_wm' ),
			'items_list_navigation'=> __( 'Items list navigation', 'pita_wm' ),
			'filter_items_list'    => __( 'Filter items list', 'pita_wm' ),
		);
		$args = array(
			'label'              => __( 'pita_portfolio', 'pita_wm' ),
			'description'        => __( 'Service car for theme Pita WM', 'pita_wm' ),
			'labels'             => $labels,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'taxonomies'         => array( 'pita_cat_portfolio' ),
			'hierarchical'       => false,
			'public'             => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'menu_position'      => 6,
			'show_in_admin_bar'  => true,
			'show_in_nav_menus'  => true,
			'can_export'         => true,
			'has_archive'        => true,
			'exclude_from_search'=> false,
			'publicly_queryable' => true,
			'capability_type'    => 'page',
		);
		register_post_type( 'pita_portfolio', $args );
	}

	public function create_taxonomies(){
		$labels = array(
			'name'             => _x( 'Category', 'taxonomy general name', 'pita_wm' ),
			'singular_name'    => _x( 'Category', 'taxonomy singular name', 'pita_wm' ),
			'search_items'     => __( 'Search Category', 'pita_wm' ),
			'all_items'        => __( 'All Category', 'pita_wm' ),
			'parent_item'      => __( 'Parent Category', 'pita_wm' ),
			'parent_item_colon'=> __( 'Parent Category:', 'pita_wm' ),
			'edit_item'        => __( 'Edit Category', 'pita_wm' ),
			'update_item'      => __( 'Update Category', 'pita_wm' ),
			'add_new_item'     => __( 'Add New Category', 'pita_wm' ),
			'new_item_name'    => __( 'New Category Name', 'pita_wm' ),
			'menu_name'        => __( 'Category', 'pita_wm' ),
		);

		$args = array(
			'hierarchical'     => true,
			'labels'           => $labels,
			'show_ui'          => true,
			'show_admin_column'=> true,
			'query_var'        => true,
			'rewrite'          => array( 'slug' => 'pita_cat_service' ),
		);

		register_taxonomy( 'pita_cat_service', array( 'pita_service' ), $args );

		$labels = array(
			'name'             => _x( 'Category', 'taxonomy general name', 'pita_wm' ),
			'singular_name'    => _x( 'Category', 'taxonomy singular name', 'pita_wm' ),
			'search_items'     => __( 'Search Category', 'pita_wm' ),
			'all_items'        => __( 'All Category', 'pita_wm' ),
			'parent_item'      => __( 'Parent Category', 'pita_wm' ),
			'parent_item_colon'=> __( 'Parent Category:', 'pita_wm' ),
			'edit_item'        => __( 'Edit Category', 'pita_wm' ),
			'update_item'      => __( 'Update Category', 'pita_wm' ),
			'add_new_item'     => __( 'Add New Category', 'pita_wm' ),
			'new_item_name'    => __( 'New Category Name', 'pita_wm' ),
			'menu_name'        => __( 'Category', 'pita_wm' ),
		);

		$args = array(
			'hierarchical'     => true,
			'labels'           => $labels,
			'show_ui'          => true,
			'show_admin_column'=> true,
			'query_var'        => true,
			'rewrite'          => array( 'slug' => 'pita_cat_portfolio' ),
		);

		register_taxonomy( 'pita_cat_portfolio', array( 'pita_portfolio' ), $args );
	}
}
