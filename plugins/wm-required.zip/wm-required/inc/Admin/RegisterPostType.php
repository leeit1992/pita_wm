<?php 
namespace PitaPlugin\Admin;

/**
 * @category Core
 * @version 1.0
 * @author Pita
 * @package Register post type
 */
class RegisterPostType 
{
}
