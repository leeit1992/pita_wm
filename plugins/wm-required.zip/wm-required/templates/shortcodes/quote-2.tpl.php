<!-- Quote 2 -->
<section id="twitter" style="background-image: url('<?php echo wp_get_attachment_url( $atts['quote_background'] ); ?>')">
    <div class="container">
        <div class="row wow fadeInUp" data-wow-delay=".4s">
            <span class="icofont moon-<?php echo isset( $atts['quote_icon'] ) ? $atts['quote_icon'] : ''; ?>"></span>
            <div id="owl-twitter">
                <?php foreach ($listQuote as $value): ?>
                <div class="item">
                    <p><?php echo $value['quote_content']; ?></p>
                    <span><?php echo $value['quote_time']; ?></span>
                    <ul>
                        <li><a href="#" title="Reply">Reply</a></li>
                        <li><a href="#" title="Retweets">Retweets</a></li>
                        <li><a href="#" title="Favotire">Favotire</a></li>
                    </ul>
                </div>
                <?php endforeach ?>
            </div>
        </div>
    </div>
</section>
<!-- End / quote 2 -->
