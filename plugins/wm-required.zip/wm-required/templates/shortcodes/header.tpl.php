<!-- Header -->
    <header id="header-wrap" class="ver3">
        <!-- Slide banner -->
        <div id="owl-banner">
            <?php
                if ( isset( $atts['header_background'] ) ) {
                    $listBackground = explode(',' , $atts['header_background']);
                }
                foreach ($listBackground as $value) { ?>
                    <div class="item">
                        <img src="<?php echo wp_get_attachment_url( $value ); ?>" alt="">
                    </div>
            <?php
                }
            ?>
        </div>
        <!-- End / Slide banner -->

        <div class="container">
            <div class="row">

                <div class="logo">
                    <a href="index.html">
                        <?php if ( isset( $atts['header_logo'] ) ): ?>
                            <img src="<?php echo wp_get_attachment_url( $atts['header_logo'] ) ?>" alt="">
                        <?php endif ?>
                        
                    </a>
                </div>

                <h3 class="tt1">
                    <span><?php echo isset( $atts['header_title'] ) ? $atts['header_title'] : '' ?></span>
                    <?php echo isset( $atts['header_title_sub'] ) ? $atts['header_title_sub'] : '' ?></h3>

                <h2><?php echo isset( $atts['header_desc'] ) ? $atts['header_desc'] : '' ?></h2>

                <br/>

                <div class="link"><a href="<?php echo isset( $atts['header_button_link'] ) ? $atts['header_button_link'] : '' ?>"><?php echo isset( $atts['header_button_title'] ) ? $atts['header_button_title'] : '' ?></a></div>

                <div class="social-nav">
                    <ul>

                        <li><a href="<?php echo isset( $atts['header_twitter'] ) ? $atts['header_twitter'] : '' ?>">Twitter</a></li>
                        <li><a href="<?php echo isset( $atts['header_linkedin'] ) ? $atts['header_linkedin'] : '' ?>">linkedin</a></li>
                        <li><a href="<?php echo isset( $atts['header_pinterest'] ) ? $atts['header_pinterest'] : '' ?>">pinterest</a></li>
                        <li><a href="<?php echo isset( $atts['header_google'] ) ? $atts['header_google'] : '' ?>">google +</a></li>
                        <li><a href="<?php echo isset( $atts['header_dribbblee'] ) ? $atts['header_dribbblee'] : '' ?>">dribbble</a></li>
                        <li><a href="<?php echo isset( $atts['header_vimeo'] ) ? $atts['header_vimeo'] : '' ?>">vimeo</a></li>

                    </ul>
                </div>

            </div>
        </div>
    </header>
<!-- End / Header -->
