<!-- Our skill -->
    <section id="our-skill" style="background-image: url('<?php echo wp_get_attachment_url( $atts['skills_background'] ); ?>')">
        <div class="container">
            <h2><?php echo isset( $atts['skills_title'] ) ? $atts['skills_title'] : '' ?></h2>
            <p class="text"><?php echo isset( $atts['skills_desc'] ) ? $atts['skills_desc'] : '' ?></p>
            <div class="row">
                <?php
                $stt = 1;
                foreach ($listItems as $value): ?>
                    <?php if ( $stt == 1 || $stt == 4): ?>
                        <article class="col col-md-6 col-sm-12">
                            <ul>
                    <?php endif ?>
                    <li>
                        <h3><?php echo $value['skills_name']; ?></h3>
                        <div class="skillbar" data-percent="<?php echo $value['skills_numeral']; ?>%">
                            <span class="skillbar-run">
                                <span class="skillbar-percent"><?php echo $value['skills_numeral']; ?>%</span>
                            </span>
                        </div>
                    </li>
                    <?php if ( $stt == 3 || $stt == 6): ?>
                            </ul>
                        </article>
                    <?php endif ?>
                    
                <?php
                $stt += 1;
                endforeach ?>

            </div>
        </div>
    </section>
<!-- End / Our skill -->
