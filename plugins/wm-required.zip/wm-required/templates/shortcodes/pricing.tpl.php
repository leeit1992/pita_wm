<!-- Pricing -->
<section id="pricing" class="pricing-table style-1">
    <div class="container">
        <header class="header-section-ver3">
            <h2><?php echo isset( $atts['pricing_title'] ) ? $atts['pricing_title'] : '' ?></h2>
            <p><?php echo isset( $atts['pricing_desc'] ) ? $atts['pricing_desc'] : '' ?></p>
        </header>

        <div class="row">
            <?php
            $time = 0.4;
            foreach ($listItems as $value): ?>
                <article class="col-md-3 col-xs-6 col-vs-12 wow bounceInUp" data-wow-delay="<?php echo $time; ?>s">
                    <div class="inner">
                        <h2><?php echo $value['pricing_name']; ?></h2>
                        <p><?php echo $value['pricing_desc_2']; ?></p>
                        <div class="content-pc">
                            <h3>$<?php echo $value['pricing_price']; ?><span>Mo</span></h3>
                            <?php echo $value['pricing_list']; ?>
                            <a href="<?php echo $value['pricing_link']; ?>" title="Sign up">Sign up</a>
                        </div>
                    </div>
                </article>
            <?php
            $time += 0.2;
            endforeach ?>
        </div>
    </div>
</section>
<!-- End / Pricing -->
