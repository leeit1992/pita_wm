<!-- Client -->
    <section id="client">

        <div class="container">
            <div class="row">
            <?php
                $time = 0.4;
                foreach ($listClient as $value): ?>
                    <a class="wow rotateIn" data-wow-delay="<?php echo $time; ?>s" href="<?php echo $value['client_link']; ?>">
                        <img src="<?php echo wp_get_attachment_url( $value['client_image'] ); ?>" alt=""/>
                        
                    </a>

            <?php
                $time += 0.2;
                endforeach ?>
            </div>
        </div>

    </section>
<!-- End / Client -->