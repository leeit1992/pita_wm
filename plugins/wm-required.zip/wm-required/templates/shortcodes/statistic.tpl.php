<!-- Fun facts -->
    <section id="fun-facts" class="ver3 dark" style="background-image: url('<?php echo wp_get_attachment_url( $atts['statistic_background'] ); ?>')">

        <div class="container">

            <h2><?php echo isset( $atts['statistic_title'] ) ? $atts['statistic_title'] : '' ?></h2>

            <p class="text"><?php echo isset( $atts['statistic_desc'] ) ? $atts['statistic_desc'] : '' ?></p>

            <div class="row wow fadeInUp" data-wow-delay=".4s">
                <?php foreach ($listItems as $value): ?>
                    <div class="col col-md-3 col-xs-6 col-vs-12">
                        <p class="countup"><?php echo $value['statistic_number']; ?></p>
                        <p class="more-ct"><?php echo $value['statistic_name']; ?></p>
                    </div>
                <?php endforeach ?>

            </div>
        </div>

    </section>
    <!-- End / fun facts -->
