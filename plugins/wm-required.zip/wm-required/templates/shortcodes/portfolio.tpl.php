<!-- Portfolio -->
<section id="work" class="ver3">
    <div class="container">
        <header class="header-section-ver3">
            <h2><?php echo isset( $atts['portfolio_title'] ) ? $atts['portfolio_title'] : '' ?></h2>
            <p><?php echo isset( $atts['portfolio_desc'] ) ? $atts['portfolio_desc'] : '' ?></p>
        </header>

        <div class="row">
            <div id="ajax-section">

                <!-- AJAX CONTENT -->
                <div id="ajax-content-outer">
                    <div id="ajax-content-inner"></div>
                </div>
                <!-- END AJAX CONTENT -->

                <!-- LOADER -->
                <div id="loader"></div>
                <!-- END / LOADER -->

                <div id="project-navigation">
                    <!-- Close -->
                    <div id="closeProject"><a href="#loader" title="">close</a></div>
                    <!-- End / Close -->
                </div>
            </div>

            <!-- Work Filters -->
            <div  id="filters">

                <ul class="clearfix">
                    <li class="wow fadeInLeft" data-wow-delay=".4s"><a id="all" href="#" data-filter="*"><h5>All</h5></a></li>
                    <?php
                    $time = 0.6;
                    foreach ($listCatSystem as $value): ?>
                        <li class="wow fadeInLeft" data-wow-delay="<?php echo $time; ?>s">
                            <a href="#" data-filter=".<?php echo $value->slug; ?>"><h5><?php echo $value->name ?></h5>
                            </a>
                        </li>
                    <?php
                    $time += 0.2;
                    endforeach ?>
                    
                </ul>

            </div>
            <!-- End / Work Filters -->

            

            <!-- Work Wrap -->
            <div id="work-wrap" class="ver3">
                <?php if ( $listPost->have_posts() ) : ?>
                    <?php while ( $listPost->have_posts() ) : $listPost->the_post(); ?>
                    <!-- Work Item With PrettyPhoto  -->

                        <?php
                            $terms = get_the_terms( get_the_ID() , 'pita_cat_portfolio');
                            $textSlug = '';
                            foreach ($terms as $cat) {
                                $textSlug .= $cat->slug .' ';
                            }
                        ?>
                        <div class="work-item work-item-ver3 <?php echo trim( $textSlug ); ?>">

                            <div class="work-image">
                                <?php echo get_the_post_thumbnail( get_the_ID() , 'pita-thumbnail-370x313' ); ?>
                            </div>

                            <article>
                                <a href="<?php the_permalink(); ?>" class="box-view">
                                    <span class="icofont moon-eye-6"></span>
                                    <div class="caption">
                                        <h2><?php the_title(); ?></h2>
                                        <ul>
                                            <?php
                                                foreach ($terms as $cat) {
                                                    echo '<li>' . $cat->name . '</li>';
                                                }
                                            ?>
                                        </ul>
                                    </div>
                                </a>
                            </article>

                        </div>
                    <!-- End / Work Item With PrettyPhoto  -->
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>
                <?php endif; ?>
                
            </div>
            <!-- End / Work Wrap -->
        </div>
    </div>
</section>
<!-- End / Portfolio -->