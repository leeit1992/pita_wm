<!-- Testimonials -->
    <section id="testimonials" class="ver3" style="background-image: url('<?php echo wp_get_attachment_url( $atts['quote_background'] ); ?>')">

        <div class="container">
            <div class="row wow fadeInUp" data-wow-delay=".4s">
                <span class="fa fa-<?php echo isset( $atts['quote_icon'] ) ? $atts['quote_icon'] : ''; ?>"></span>

                <div id="owl-testimonials">
                    <?php foreach ($listQuote as $value): ?>
                        <div class="item">
                            <p><?php echo $value['quote_content']; ?></p>
                            <img src="<?php echo wp_get_attachment_url( $value['quote_avatar'] ); ?>" alt=""/>
                            <h2><?php echo $value['quote_name']; ?></h2>
                        </div>
                    <?php endforeach ?>
                </div>

            </div>
        </div>
    </section>

    <!-- End / Testimonials -->