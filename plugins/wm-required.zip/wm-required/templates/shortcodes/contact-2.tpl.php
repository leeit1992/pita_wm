    <!-- Start project -->

    <section id="start-project" class="start-project dark">

        <div class="container">

            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['contact_title'] ) ? $atts['contact_title'] : '' ?></h2>
                <p><?php echo isset( $atts['contact_desc'] ) ? $atts['contact_desc'] : '' ?></p>
            </header>

            <div class="row">

                <div class="contact-form wow fadeInUp" data-wow-delay=".4s">

                    <form id="contact-form" class="clearfix" action="processForm.php" method="post">
                        <div class="col-md-6">
                            <input type="text" name="name" onfocus="if(this.value == 'Full Name') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Full Name'; }" value="Full Name"/>
                        </div>

                        <div class="col-md-6">
                            <input type="text" name="email" onfocus="if(this.value == 'Email') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Email'; }" value="Email"/>
                        </div>

                        <div class="col-md-6">
                            <input type="text" name="phone" onfocus="if(this.value == 'Phone') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Phone'; }" value="Phone"/>
                        </div>

                        <div class="col-md-6">
                            <input type="text" name="website" onfocus="if(this.value == 'Website') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Website'; }" value="Website"/>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-12">
                            <textarea name="message" class="textarea-form" onfocus="if(this.value == 'Message or project description') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Message or project description'; }">Message or project description</textarea>
                        </div>

                        <div class="clearfix"></div>
                        <div id="contact-content"></div>
                        <button type="submit"><span class="icofont moon-paper-plane"></span><i id="submit-contact">Submit</i></button>

                    </form>

                </div>

            </div>
        </div>

    </section>
<!-- End / Start project -->
