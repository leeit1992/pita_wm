<!-- Start project -->
<?php if ( isset( $atts['contact_style'] )):
    $style = '';
    if ( $atts['contact_style'] == 's1'): 
        $style = 'dark';
    endif; ?>
<?php endif; ?>
<section id="start-project" class="start-project <?php echo $style; ?>">
    <div class="container">
        <header class="header-section-ver3">
            <h2><?php echo isset( $atts['contact_title'] ) ? $atts['contact_title'] : '' ?></h2>
            <p><?php echo isset( $atts['contact_desc'] ) ? $atts['contact_desc'] : '' ?></p>
        </header>

        <div class="row">
            <div class="contact-form wow fadeInUp" data-wow-delay=".4s">
                <form id="contact-form" class="clearfix" action="processForm.php" method="post">
                    <div class="col-md-6">
                        <input type="text" name="name" onfocus="if(this.value == '<?php echo isset( $atts['contact_input_1'] ) ? $atts['contact_input_1'] : '' ?>') { this.value = ''; }" onblur="if(this.value == '') { this.value = '<?php echo isset( $atts['contact_input_1'] ) ? $atts['contact_input_1'] : '' ?>'; }" value="<?php echo isset( $atts['contact_input_1'] ) ? $atts['contact_input_1'] : '' ?>"/>
                    </div>

                    <div class="col-md-6">
                        <input type="text" name="email" onfocus="if(this.value == '<?php echo isset( $atts['contact_input_2'] ) ? $atts['contact_input_2'] : '' ?>') { this.value = ''; }" onblur="if(this.value == '') { this.value = '<?php echo isset( $atts['contact_input_2'] ) ? $atts['contact_input_2'] : '' ?>'; }" value="<?php echo isset( $atts['contact_input_2'] ) ? $atts['contact_input_2'] : '' ?>"/>
                    </div>

                    <div class="col-md-6">
                        <input type="text" name="phone" onfocus="if(this.value == '<?php echo isset( $atts['contact_input_3'] ) ? $atts['contact_input_3'] : '' ?>') { this.value = ''; }" onblur="if(this.value == '') { this.value = '<?php echo isset( $atts['contact_input_3'] ) ? $atts['contact_input_3'] : '' ?>'; }" value="<?php echo isset( $atts['contact_input_3'] ) ? $atts['contact_input_3'] : '' ?>"/>
                    </div>

                    <div class="col-md-6">
                        <input type="text" name="website" onfocus="if(this.value == '<?php echo isset( $atts['contact_input_4'] ) ? $atts['contact_input_4'] : '' ?>') { this.value = ''; }" onblur="if(this.value == '') { this.value = '<?php echo isset( $atts['contact_input_4'] ) ? $atts['contact_input_4'] : '' ?>'; }" value="<?php echo isset( $atts['contact_input_4'] ) ? $atts['contact_input_4'] : '' ?>"/>
                    </div>

                    <div class="clearfix"></div>

                    <div class="col-sm-12">
                        <textarea name="message" class="textarea-form" onfocus="if(this.value == '<?php echo isset( $atts['contact_input_5'] ) ? $atts['contact_input_5'] : '' ?>') { this.value = ''; }" onblur="if(this.value == '') { this.value = '<?php echo isset( $atts['contact_input_5'] ) ? $atts['contact_input_5'] : '' ?>'; }"><?php echo isset( $atts['contact_input_5'] ) ? $atts['contact_input_5'] : '' ?></textarea>
                    </div>

                    <div class="clearfix"></div>
                    <div id="contact-content"></div>
                    <button type="submit"><span class="icofont moon-<?php echo isset( $atts['contact_button_icon'] ) ? $atts['contact_button_icon'] : '' ?>"></span><i id="submit-contact"><?php echo isset( $atts['contact_button'] ) ? $atts['contact_button'] : '' ?></i></button>

                </form>
            </div>
        </div>
    </div>
</section>
<!-- End / Start project -->
