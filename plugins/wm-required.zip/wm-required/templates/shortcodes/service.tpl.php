<!-- Services -->
    <section id="services" class="ver3">
        <div class="container">
            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['service_title'] ) ? $atts['service_title'] : '' ?></h2>
                <p><?php echo isset( $atts['service_desc'] ) ? $atts['service_desc'] : '' ?></p>
            </header>

            <div class="row feature-list style-2">
               
                <?php
                    $stt = 1;
                    $fadeIn = '';
                    foreach ($listPost as $value) {
                        $time = 0.8;
                        switch ($stt) {
                            case 1:
                                $fadeIn = 'Left';
                                break;
                            case 2:
                                $fadeIn = 'Up';
                                $time = 0.4;
                                break;
                            case 3:
                                $fadeIn = 'Right';
                                break;

                            default:
                                $fadeIn = 'Up';
                                break;
                        }
                        ?>

                        <article class="col-sm-4 col-xs-12 wow fadeIn<?php echo $fadeIn; ?>Big" data-wow-delay="<?php echo $time; ?>">
                            <div class="inner">
                                <div class="top">
                                    <a href="<?php echo $value->guid; ?>" class="top-info">
                                        <span class="icofont moon-<?php echo get_post_meta( $value->ID, 'wm_service_icon', true ) ?>"></span>
                                        <h2><?php echo $value->post_title; ?></h2>
                                    </a>
                                </div>

                                <div class="bottom">
                                    <p><?php echo $value->post_excerpt; ?></p>
                                </div>
                            </div>
                        </article>
                    <?php
                        $stt += 1;
                    }
                    ?>
            </div>

            <div class="services-link"><a href="<?php echo isset( $atts['service_link'] ) ? $atts['service_link'] : '' ?>"><span class="icofont moon-cog-3"></span>Services list</a></div>
        </div>
    </section>
<!-- End / Services -->
