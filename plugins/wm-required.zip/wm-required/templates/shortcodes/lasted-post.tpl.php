<!-- Lasted post -->
    <section id="lasted-post" class="lasted-post">

        <div class="container">

            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['post_title'] ) ? $atts['post_title'] : '' ?></h2>
                <p><?php echo isset( $atts['post_desc'] ) ? $atts['post_desc'] : '' ?></p>
            </header>

            <div class="row wow fadeInUp" data-wow-delay=".4s">

                <div id="owl-lasted-post" class="post-list">
                
                    <?php foreach ($listPost as $value): ?>

                    <div class="item">

                        <a class="head popup-image" href="<?php echo get_the_permalink( $value->ID ) ?>">
                            <img src="<?php echo get_the_post_thumbnail( $value->ID, 'size-thumbnail-lasted-post' ); ?>" alt=""/>
                            
                            <span class="icofont icofont-view moon-eye-6"></span>
                        </a>

                        <div class="caption">
                            <?php
                                $postFormat = '';
                                $postFormat = get_post_format( $value->ID );
                                switch ( $postFormat ) {
                                    case '':
                                    case 'aside':
                                        $postFormat = 'pencil';
                                        break;
                                    case 'gallery':
                                        $postFormat = 'images';
                                        break;
                                    case 'quote':
                                        $postFormat = 'quotes-left';
                                        break;
                                    case 'video':
                                        $postFormat = 'film';
                                        break;
                                }
                            ?>
                            <span class="icofont moon-<?php echo $postFormat; ?>"></span>

                            <h2><?php echo $value->post_title; ?></h2>

                            <div class="meta">
                                <span><?php echo strtolower( date( 'd F Y', strtotime( $value->post_date ) ) );  ?></span>
                                <span><?php echo get_comments_number( $value->ID ); ?> Comments</span>
                            </div>

                            <p><?php echo $value->post_excerpt; ?></p>

                            <a href="<?php echo get_the_permalink($value->ID) ?>">read more</a>
                        </div>

                    </div>
                    <?php endforeach ?>

                </div>

            </div>
        </div>

    </section>
<!-- End / Lasted post -->
