<!-- Lasted post -->
    <section id="lasted-post" class="lasted-post">

        <div class="container">

            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['post_title'] ) ? $atts['post_title'] : '' ?></h2>
                <p><?php echo isset( $atts['post_desc'] ) ? $atts['post_desc'] : '' ?></p>
            </header>

            <div class="row wow fadeInUp" data-wow-delay=".4s">

                <div id="owl-lasted-post" class="post-list">
                
                    <?php foreach ($listPost as $value): ?>
                    <div class="item">

                        <a class="head popup-image" href="<?php echo get_the_permalink($value->ID) ?>">
                            <img src="images/post/img-1-post.jpg" alt=""/>
                            <span class="icofont icofont-view moon-eye-6"></span>
                        </a>

                        <div class="caption">
                            <span class="icofont moon-pencil-4"></span>

                            <h2><?php echo $value->post_title ?></h2>

                            <div class="meta">
                                <span>19 february 2014</span>
                                <span>20 Comments</span>
                            </div>

                            <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam,
                                nisi ut aliquid ex ea commodi consequatur.</p>

                            <a href="<?php echo get_the_permalink($value->ID) ?>">read more</a>
                        </div>

                    </div>
                    <?php endforeach ?>

                </div>

            </div>
        </div>

    </section>
<!-- End / Lasted post -->
