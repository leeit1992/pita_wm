<!-- Team -->
    <section id="team" class="team">
        <div class="container">
            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['teams_title'] ) ? $atts['teams_title'] : '' ?></h2>
                <p><?php echo isset( $atts['teams_desc'] ) ? $atts['teams_desc'] : '' ?></p>
            </header>
            <div class="row team-list">

            <?php
                $time = 0.4;
                foreach ($listItems as  $value): ?>
                    <article class="col-sm-4 col-xs-12 wow fadeInUp" data-wow-delay="<?php echo $time; ?>s">

                        
                        <?php echo wp_get_attachment_image( $value['teams_avatar'],'size-thumbnail-teams' ); ?>
                        <div class="caption">

                            <h3><?php echo $value['teams_name']; ?></h3>

                            <h4><?php echo $value['teams_job']; ?></h4>

                            <p><?php echo $value['teams_bio']; ?></p>

                            <ul class="social">

                                <li>
                                    <a href="<?php echo $value['teams_twitter']; ?>"><span class="fa fa-twitter"></span></a>
                                </li>
                                <li>
                                    <a href="<?php echo $value['teams_dribbble']; ?>"><span class="fa fa-dribbble"></span></a>
                                </li>
                                <li>
                                    <a href="<?php echo $value['teams_tumblr']; ?>"><span class="fa fa-tumblr-square"></span></a>
                                </li>

                            </ul>

                        </div>

                    </article>
            <?php
                $time += 0.2;
                endforeach ?>

            </div>
        </div>
    </section>
    <!-- End / Team -->