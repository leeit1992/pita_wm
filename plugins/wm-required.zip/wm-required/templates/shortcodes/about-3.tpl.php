<section class="banner-product">
    <div class="background-banner" 
    <?php if ( !empty( $atts['about_background'] )) {
        echo 'style="background-image: url('. wp_get_attachment_url( $atts['about_background'] ) .');"';
    } ?>
    ></div>
    <div class="overlay-banner"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="product-info">
                    <div class="info">
                        <h3><?php echo isset( $atts['about_title'] ) ? $atts['about_title'] : '' ?></h3>
                        <h4><?php echo isset( $atts['about_title_sub'] ) ? $atts['about_title_sub'] : '' ?></h4>
                        <p><?php echo isset( $atts['about_desc'] ) ? $atts['about_desc'] : '' ?></p>
                    </div>
                    <div class="demo">
                        <a href="<?php echo isset( $atts['about_link_1'] ) ? $atts['about_link_1'] : '' ?>" target="_blank"><?php echo isset( $atts['about_button_1'] ) ? $atts['about_button_1'] : '' ?></a>
                        <a class="buy-link" href="<?php echo isset( $atts['about_link_2'] ) ? $atts['about_link_2'] : '' ?>"><?php echo isset( $atts['about_button_2'] ) ? $atts['about_button_2'] : '' ?></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-6" style="position: static;">
                <div class="banner-image">
                    <?php if ( !empty( $atts['about_image'] )): ?>
                        <img src="<?php echo wp_get_attachment_url( $atts['about_image'] ) ?>" />
                    <?php endif ?>
                </div>
            </div>
        </div>
    </div>
</section>