<section id="content-area">
    <div id="block-system-main" class="block clearfix">
        <div class="content">
            <article class="node-product-display">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <ul class="tabs-theme">
                                <li><?php echo isset( $atts['features_title'] ) ? $atts['features_title'] : '' ?></li>
                            </ul>
                            <div class="field field-name-body">
                                <div class="field-items">
                                    <div class="field-item" property="content:encoded">
                                    <?php
                                    $i = 1;
                                    foreach ($listItems as $value): ?>
                                        <?php if (($i % 2) != 0): ?>
                                        <div class="row">
                                        <?php endif ?>
                                            <div class="col-md-6 col-awe-5 <?php echo (($i % 2) == 0) ? 'col-awe-offset-1' : ''; ?>">
                                                <div class="detail">
                                                    <h3><?php echo $value['features_heading']; ?></h3>
                                                    <p><?php echo $value['features_content']; ?></p>
                                                </div>
                                            </div>
                                        <?php if (($i % 2) == 0): ?>
                                        </div>
                                        <?php endif ?>
                                    <?php
                                    $i++;
                                    endforeach ?>
                                    <?php if (($i % 2) == 0): ?>
                                    </div>
                                    <?php endif ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="node-sidebar">
                                <div class="info-theme">
                                    <div class="field">
                                        <div class="field-label"><?php echo isset( $atts['features_info_label_1'] ) ? $atts['features_info_label_1'] : '' ?></div>
                                        <div class="field-items">
                                            <div class="field-item"><?php echo isset( $atts['features_info_item_1'] ) ? $atts['features_info_item_1'] : '' ?></div>
                                        </div>
                                    </div>
                                    <div class="field">
                                        <div class="field-label"><?php echo isset( $atts['features_info_label_2'] ) ? $atts['features_info_label_2'] : '' ?></div>
                                        <div class="field-items">
                                            <a href="<?php echo isset( $atts['features_info_link_2'] ) ? $atts['features_info_link_2'] : '' ?>"><?php echo isset( $atts['features_info_item_2'] ) ? $atts['features_info_item_2'] : '' ?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="document-support">
                                    <div class="demo-link">
                                        <a href="<?php echo isset( $atts['features_link_1'] ) ? $atts['features_link_1'] : '' ?>"><?php echo isset( $atts['features_button_1'] ) ? $atts['features_button_1'] : '' ?></a> </div>
                                    <div class="demo-link detail-link">
                                        <a href="<?php echo isset( $atts['features_link_2'] ) ? $atts['features_link_2'] : '' ?>"><?php echo isset( $atts['features_button_2'] ) ? $atts['features_button_2'] : '' ?></a> </div>
                                </div>
                                <div class="more-add-cart">
                                    <div class="add-to-cart">
                                        <a class="buy-link" href="<?php echo isset( $atts['features_link_3'] ) ? $atts['features_link_3'] : '' ?>" target="_blank"><?php echo isset( $atts['features_button_3'] ) ? $atts['features_button_3'] : '' ?></a>
                                    </div>
                                    <div class="demo-product">
                                        <a href="<?php echo isset( $atts['features_link_4'] ) ? $atts['features_link_4'] : '' ?>"><?php echo isset( $atts['features_button_4'] ) ? $atts['features_button_4'] : '' ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</section>