<!-- About -->
    <section id="about" class="ver3">
        <div class="container">
            <header class="header-section-ver3">
                <h2><?php echo isset( $atts['about_title'] ) ? $atts['about_title'] : '' ?></h2>
                <p><?php echo isset( $atts['about_desc'] ) ? $atts['about_desc'] : '' ?></p>
            </header>

            <div class="row feature-list style-1 text-center">
                <?php
                $time = 0.4;
                foreach ($listItems as $value): ?>
                    <article class="col-sm-4 col-xs-12 wow rollIn" data-wow-delay="<?php echo $time; ?>s">
                
                        <a href="<?php echo $value['about_link']; ?>">
                            <span class="fa fa-<?php echo $value['about_icon']; ?>"></span>
                        </a>
                    
                        <h3><?php echo $value['about_title_2']; ?></h3>
                    
                        <p><?php echo $value['about_desc_2']; ?></p>
                    
                    </article>
                <?php
                $time += 0.2;
                endforeach ?>
            </div>
        </div>
    </section>
<!-- End / About -->