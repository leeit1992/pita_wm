<!-- DO you have an ideas -->
    <section id="do-you-have-an-ideas">

        <div class="container">
            <div class="row">

                <div class="col col-lg-8 col-lg-offset-2 col-md-12">

                    <div class="text">
                        <h2><?php echo isset( $atts['contact_title'] ) ? $atts['contact_title'] : '' ?></h2>
                        <p><?php echo isset( $atts['contact_desc'] ) ? $atts['contact_desc'] : '' ?></p>
                    </div>

                    <a class="contact-link" href="#start-project">Contact us</a>

                </div>
            </div>
        </div>

    </section>
<!-- End / DO you have an ideas -->
