<!-- Our office -->
    <div id="map_canvas" class="dark"></div>
    <?php
        if ( isset( $atts['office_background'] ) ) {
            $background_image = wp_get_attachment_image_src( $atts['office_background'], 'full' );
        }
    ?>
    <section id="our-office-dark" style="background-image: url('<?php echo $background_image[0]; ?>')">
        <div class="container">

            <h2><?php echo isset( $atts['office_title'] ) ? $atts['office_title'] : '' ?></h2>

            <p class="text"><?php echo isset( $atts['office_desc'] ) ? $atts['office_desc'] : '' ?></p>

            <span class="open-map">+</span>

            <div class="row">

                <article class="mail col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-envelop"></span></h3>
                    <a href="#"><?php echo isset( $atts['office_email'] ) ? $atts['office_email'] : '' ?></a>
                </article>

                <article class="address col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-location-3"></span></h3>
                    <p><?php echo isset( $atts['office_address'] ) ? $atts['office_address'] : '' ?></p>
                </article>

                <article class="phone col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-phone-3"></span></h3>
                    <p><?php echo isset( $atts['office_phone'] ) ? $atts['office_phone'] : '' ?></p>
                </article>

            </div>
        </div>

    </section>
<!-- End / Our office -->
