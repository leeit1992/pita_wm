<!-- News letter -->
    <section id="news-letter">
        <div class="container">
            <header>
                <span class="icofont moon-<?php echo isset( $atts['subscribe_icon'] ) ? $atts['subscribe_icon'] : '' ?>"></span>
                <h2><?php echo isset( $atts['subscribe_title'] ) ? $atts['subscribe_title'] : '' ?></h2>
                <p><?php echo isset( $atts['subscribe_desc'] ) ? $atts['subscribe_desc'] : '' ?></p>
            </header>

            <div class="row">

                <div class="col-md-6 col-md-offset-3 wow fadeInUp" data-wow-delay=".4s">

                    <form>
                        <input type="text" onfocus="if(this.value == 'Enter your email...') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Enter your email...'; }" value="Enter your email..."/>
                        <button type="submit"><?php echo isset( $atts['subscribe_button'] ) ? $atts['subscribe_button'] : '' ?></button>
                    </form>

                </div>


            </div>
        </div>
    </section>
<!-- End / News letter -->