<!-- Our office -->
    <div id="map_canvas" class="dark"></div>
    <section id="our-office-dark" style="background-image: url('<?php echo wp_get_attachment_url( $atts['about_background'] ); ?>')">
        <div class="container">

            <h2><?php echo isset( $atts['about_title'] ) ? $atts['about_title'] : '' ?></h2>

            <p class="text"><?php echo isset( $atts['about_desc'] ) ? $atts['about_desc'] : '' ?></p>

            <span class="open-map">+</span>

            <div class="row">

                <article class="mail col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-<?php echo isset( $atts['about_icon_3'] ) ? $atts['about_icon_3'] : '' ?>"></span></h3>
                    <p><?php echo isset( $atts['about_text_1'] ) ? $atts['about_text_1'] : '' ?></p>
                </article>

                <article class="address col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-<?php echo isset( $atts['about_icon_2'] ) ? $atts['about_icon_2'] : '' ?>"></span></h3>
                    <p><?php echo isset( $atts['about_text_2'] ) ? $atts['about_text_2'] : '' ?></p>
                </article>

                <article class="phone col-xs-4 col-vs-12 wow fadeInUp" data-wow-delay="0.4">
                    <h3><span class="icofont moon-<?php echo isset( $atts['about_icon_3'] ) ? $atts['about_icon_3'] : '' ?>"></span></h3>
                    <p><?php echo isset( $atts['about_text_3'] ) ? $atts['about_text_3'] : '' ?></p>
                </article>

            </div>
        </div>

    </section>
<!-- End / Our office -->
